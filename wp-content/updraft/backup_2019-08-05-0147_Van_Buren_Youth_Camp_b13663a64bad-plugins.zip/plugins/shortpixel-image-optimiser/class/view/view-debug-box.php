<?php
// Debug Box to load Log File
namespace ShortPixel;
wp_enqueue_script( 'jquery-ui-draggable' );
?>

<style>
  .sp_debug_box
  {
    position: absolute;
    right: 0px;
    top: 50px;
    background-color: #fff;
    width: 100px;
    z-index: 1000000;
    border: 1px solid #000;
  }
  .sp_debug_box .header
  {
    min-height: 10px;
    background: #000;
    color: #fff;
  }
  .sp_debug_box .content_box
  {
    background: #ccc;
  }
</style>

<script language='javascript'>
  jQuery(document).ready(function($)
  {
     $( ".sp_debug_box" ).draggable();

  });
</script>

<div class='sp_debug_box'>
   <div class='header'>Debug Box </div>
   <a target="_blank" href='<?php echo $this->layout->logLink ?>'>Logfile</a>
   <div class='content_box'>

   </div>
</div>
