<?php

class ShortPixelFileRightsException extends Exception {
    
}

