                        <?php
                        $has_content_headline = get_field( "content_headline" );
                        if ( $has_content_headline ) { ?>

                            <h2 class="heading"><?php the_field('content_headline'); ?></h2> 

                        <? } ?>


                        