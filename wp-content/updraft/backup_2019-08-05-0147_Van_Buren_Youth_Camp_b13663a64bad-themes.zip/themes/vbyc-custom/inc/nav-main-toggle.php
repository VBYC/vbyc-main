                    <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#main-navbar" aria-controls="main-navbar" aria-expanded="false">
                        <span class="sr-only">Toggle</span> 
                        Menu
                    </button>