<script type="text/javascript">
    window.location = "/styleguide/index.php"
</script>