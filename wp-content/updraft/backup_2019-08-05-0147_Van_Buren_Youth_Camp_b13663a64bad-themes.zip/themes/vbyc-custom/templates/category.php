<? /* 
Template Name: Category (blank)
*/ ?>